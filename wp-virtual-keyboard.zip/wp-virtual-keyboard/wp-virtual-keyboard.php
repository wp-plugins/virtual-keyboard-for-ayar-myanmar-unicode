<?php
/*
Plugin Name: WP-Virtual-KeyBoard
Plugin URI: http://www.ayarunicodegroup.com/
Description: Displays a virtual, on-screen keyboard to enter the wordpress password in a safer way, for example in internet cafés. Easy Typing in comment form. Support burmese language.Modified wp-virtual-kb plugins.
Version: 1.0
Author: Sithu Thwin
Author URI: http://www.myatsayar.com
Credits:Marcel Bokhorst
*/

/*
	Copyright 2009, 2010 Marcel Bokhorst

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*
	jQuery JavaScript Library
		licensed under both the GNU General Public License and MIT License
		downloaded from http://jquery.com/

	JavaScript Virtual Keyboard
		by Dmitry Khudorozhkov
		licensed under CPOL (see http://www.codeproject.com/info/cpol10.aspx)
		downloaded from http://www.codeproject.com/KB/scripting/jvk.aspx

	Keyboard icon
		licensed under GPLv3 (see http://www.gnu.org/copyleft/gpl-3.0.html)
		downloaded from http://commons.wikimedia.org/wiki/File:Gnome-input-keyboard.svg
*/

#error_reporting(E_ALL);
if(defined('WPVKB_VERSION')) return;
define('WPVKB_VERSION', '1.0');
define('WPVKB_PLUGIN_PATH', dirname(__FILE__));
define('WPVKB_PLUGIN_FOLDER', basename(WPVKB_PLUGIN_PATH));

if(defined('WP_ADMIN') && defined('FORCE_SSL_ADMIN') && FORCE_SSL_ADMIN){
    define('WPVKB_PLUGIN_URL', rtrim(str_replace('http://','https://',get_option('siteurl')),'/') . '/'. PLUGINDIR . '/' . basename(dirname(__FILE__)) );
}else{
    define('WPVKB_PLUGIN_URL', rtrim(get_option('siteurl'),'/') . '/'. PLUGINDIR . '/' . basename(dirname(__FILE__)) );
}
// Handle initialize
function wpvkb_init() {
	// I18n
	load_plugin_textdomain('wp-virtual-kb', false, basename(dirname(__FILE__)));
}
function DefaultSettings () { 
$default = 'on';
			#Set Default Settings
			if( !get_option('wpvkb_num_pad') ){ #Set Defaults if no values exist
				add_option( 'wpvkb_num_pad',$default);
			}
			if( !get_option('wpvkb_1pixel_gap') ){ #Set Defaults if no values exist
				add_option( 'wpvkb_1pixel_gap',$default);
			}
			if( !get_option('wpvkb_key_flash') ){ #Set Defaults if no values exist
				add_option( 'wpvkb_key_flash',$default);
			}
}
// Create options page
function wpvkb_admin_menu() {
	add_options_page(
		__('WP-Virtual-KB', 'wp-virtual-kb'),
		__('WP-Virtual-KB', 'wp-virtual-kb'),
		'manage_options',
		__FILE__,
		'wpvkb_options');
}

// Render option page
function wpvkb_options() {
	?>
	<div class="wrap">
	<h2><?php _e('WP virtual keyboard', 'wp-virtual-kb') ?></h2>

	<form method="post" action="options.php">
	<?php wp_nonce_field('update-options'); ?>

	<table class="form-table">

	<tr valign="top">
	<th scope="row"><?php _e('Keyboard initial visible', 'wp-virtual-kb') ?></th>
	<td><input type="checkbox" name="wpvkb_initial_visible" <?php if (get_option('wpvkb_initial_visible')) echo 'checked="checked"'; ?>></td>
	</tr>

	<tr valign="top">
	<th scope="row"><?php _e('Show key flash on click', 'wp-virtual-kb') ?></th>
	<td><input type="checkbox" name="wpvkb_key_flash" <?php if (get_option('wpvkb_key_flash')) echo 'checked="checked"'; ?>></td>
	</tr>

	<tr valign="top">
	<th scope="row"><?php _e('Show numeric key pad', 'wp-virtual-kb') ?></th>
	<td><input type="checkbox" name="wpvkb_num_pad" <?php if (get_option('wpvkb_num_pad')) echo 'checked="checked"'; ?>></td>
	</tr>

	<tr valign="top">
	<th scope="row"><?php _e('1-pixel gap between keys', 'wp-virtual-kb') ?></th>
	<td><input type="checkbox" name="wpvkb_1pixel_gap" <?php if (get_option('wpvkb_1pixel_gap')) echo 'checked="checked"'; ?>></td>
	</tr>

	<tr valign="top">
	<th scope="row"><?php _e('Virtual keyboard mandatory', 'wp-virtual-kb') ?></th>
	<td><input type="checkbox" name="wpvkb_mandatory" <?php if (get_option('wpvkb_mandatory')) echo 'checked="checked"'; ?>></td>
	</tr>


	</table>

	<input type="hidden" name="action" value="update" />
	<input type="hidden" name="page_options" value="wpvkb_initial_visible,wpvkb_key_flash,wpvkb_num_pad,wpvkb_1pixel_gap,wpvkb_donated,wpvkb_mandatory" />

	<p class="submit">
	<input type="submit" class="button-primary" value="<?php _e('Save Changes', 'wp-virtual-kb') ?>" />
	</p>

	</form>
	</div>
<?php
}

// Add style sheet & JavaScript to the head of the page
function wpvkb_login_head() {
	wp_enqueue_script('jquery');
	wp_deregister_script('gdsr_script');
	wp_print_scripts();
?>
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('wp-virtual-keyboard.css', __FILE__); ?>" />
	<script type="text/javascript" src="<?php echo plugins_url('vkboardsc.js', __FILE__); ?>"></script>
	<script type="text/javascript">
	/* <![CDATA[ */
		function wpvkb_callback(ch) {
			var text = document.getElementById('user_pass');
			val = text.value;
			switch (ch) {
				case 'BackSpace':
					var min = (val.charCodeAt(val.length - 1) == 10) ? 2 : 1;
					text.value = val.substr(0, val.length - min);
					break;
				case "Enter":
					wpvkb_visible = false;
					wpvkb.Show(wpvkb_visible);
					var form = document.getElementById('loginform');
					form.submit();
					break;
				default:
					text.value += ch;
			}
		}
	/* ]]> */
	</script>
<?php
}
// Add style sheet & JavaScript to the head of the page
function wpvkb_comment_head() {
	wp_enqueue_script('jquery');
	wp_deregister_script('gdsr_script');
	wp_print_scripts();
?>
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('wp-virtual-keyboard.css', __FILE__); ?>" />
	<script type="text/javascript" src="<?php echo plugins_url('vkboardsc.js', __FILE__); ?>"></script>
	<script type="text/javascript">
	/* <![CDATA[ */
		function wpvkb_callback(ch) {
			var text = document.getElementById('comment');
			val = text.value;
			switch (ch) {
				case 'BackSpace':
					var min = (val.charCodeAt(val.length - 1) == 10) ? 2 : 1;
					text.value = val.substr(0, val.length - min);
					break;
				case "Enter":
					wpvkb_visible = false;
					wpvkb.Show(wpvkb_visible);
					var form = document.getElementById('commentform');
					form.submit();
					break;
				default:
					text.value += ch;
			}
		}
	/* ]]> */
	</script>
<?php
}
// Modify the login form
function wpvkb_login_form() {
?>
	<script type="text/javascript">
	/* <![CDATA[ */
		var wpvkb;
		/* Decode options */
		var wpvkb_visible = <?php echo get_option('wpvkb_initial_visible') ? 'true' : 'false'; ?>;
		var wpvkb_key_flash = <?php echo get_option('wpvkb_key_flash') ? 'true' : 'false'; ?>;
		var wpvkb_num_pad = <?php echo get_option('wpvkb_num_pad') ? 'true' : 'false'; ?>;
		var wpvkb_1pixel_gap = <?php echo get_option('wpvkb_1pixel_gap') ? 'true' : 'false'; ?>;
		var wpvkb_mandatory = <?php echo get_option('wpvkb_mandatory') ? 'true' : 'false'; ?>;

		jQuery(document).ready(function($) {
			if (!wpvkb_mandatory) {
				/* Make room for icon */
				$('#user_pass').addClass('wpvkb_small');

				/* Add image to toggle keyboard */
				var wpvkb_img_url = "<?php echo plugins_url('Gnome-input-keyboard.png', __FILE__); ?>";
				var wpvkb_img_alt = "<?php _e('Virtual keyboard interface', 'wp-virtual-kb') ?>";
				var wpvkb_img_title = "<?php _e('Display virtual keyboard interface', 'wp-virtual-kb') ?>";
				var wpvkb_img = $('<img id="wpvkb_img" src="' + wpvkb_img_url + '" alt="' + wpvkb_img_alt + '" title="' + wpvkb_img_title + '">');
				$('#user_pass').after(wpvkb_img);

				/* Handle image click */
				wpvkb_img.click(function() {
					wpvkb_visible = !wpvkb_visible;
					wpvkb.Show(wpvkb_visible);
				});
			}

			/* Add container for keyboard */
			$('#user_pass').parent().parent().after($('<div id="wpvkb_div">'));

			/* Create virtual keyboard */
			wpvkb = new VKeyboard('wpvkb_div',	// container's id, mandatory
				wpvkb_callback,					// reference to callback function, mandatory
												// (this & following parameters are optional)
				false,							// create the arrow keys or not?
				false,							// create up and down arrow keys?
				false,							// reserved
				wpvkb_num_pad,					// create the numpad or not?
				"",								// font name ("" == system default)
				"12px",							// font size in px
				"#000",							// font color
				"#F00",							// font color for the dead keys
				"#FFF",							// keyboard base background color
				"#FFF",							// keys' background color
				"#DDD",							// background color of switched/selected item
				"#777",							// border color
				"#CCC",							// border/font color of "inactive" key (key with no value/disabled)
				"#FFF",							// background color of "inactive" key (key with no value/disabled)
				"#F77",							// border color of language selector's cell
				wpvkb_key_flash,					// show key flash on click? (false by default)
				"#CC3300",						// font color during flash
				"#FF9966",						// key background color during flash
				"#CC3300",						// key border color during flash
				false,							// embed VKeyboard into the page?
				wpvkb_1pixel_gap,				// use 1-pixel gap between the keys?
				0);								// index (0-based) of the initial layout
			wpvkb.Show(wpvkb_visible);

			/* Make virtual keyboard mandatory */
			if (wpvkb_mandatory) {
				$('#user_pass').attr('readonly', true);
				$('#user_pass').focus(function() {
					wpvkb.Show(true);
				});
				$('#user_pass').blur(function() {
					wpvkb.Show(false);
				});
			}
		});
	/* ]]> */
	</script>
<?php
}
// Modify the login form
function wpvkb_comment_form() {
?>
	<script type="text/javascript">
	/* <![CDATA[ */
		var wpvkb;
		/* Decode options */
		var wpvkb_visible = <?php echo get_option('wpvkb_initial_visible') ? 'true' : 'false'; ?>;
		var wpvkb_key_flash = <?php echo get_option('wpvkb_key_flash') ? 'true' : 'false'; ?>;
		var wpvkb_num_pad = <?php echo get_option('wpvkb_num_pad') ? 'true' : 'false'; ?>;
		var wpvkb_1pixel_gap = <?php echo get_option('wpvkb_1pixel_gap') ? 'true' : 'false'; ?>;
		var wpvkb_mandatory = <?php echo get_option('wpvkb_mandatory') ? 'true' : 'false'; ?>;

		jQuery(document).ready(function($) {
			if (!wpvkb_mandatory) {
				/* Make room for icon */
				$('#comment').addClass('wpvkb_small');

				/* Add image to toggle keyboard */
				var wpvkb_img_url = "<?php echo plugins_url('Gnome-input-keyboard.png', __FILE__); ?>";
				var wpvkb_img_alt = "<?php _e('Virtual keyboard interface', 'wp-virtual-kb') ?>";
				var wpvkb_img_title = "<?php _e('Display virtual keyboard interface', 'wp-virtual-kb') ?>";
				var wpvkb_img = $('<img id="wpvkb_img" src="' + wpvkb_img_url + '" alt="' + wpvkb_img_alt + '" title="' + wpvkb_img_title + '">');
				$('#submit').after(wpvkb_img);

				/* Handle image click */
				wpvkb_img.click(function() {
					wpvkb_visible = !wpvkb_visible;
					wpvkb.Show(wpvkb_visible);
				});
			}

			/* Add container for keyboard */
			$('#comment').parent().parent().after($('<div id="wpvkb_div">'));

			/* Create virtual keyboard */
			wpvkb = new VKeyboard('wpvkb_div',	// container's id, mandatory
				wpvkb_callback,					// reference to callback function, mandatory
												// (this & following parameters are optional)
				false,							// create the arrow keys or not?
				false,							// create up and down arrow keys?
				false,							// reserved
				wpvkb_num_pad,					// create the numpad or not?
				"",								// font name ("" == system default)
				"12px",							// font size in px
				"#000",							// font color
				"#F00",							// font color for the dead keys
				"#FFF",							// keyboard base background color
				"#FFF",							// keys' background color
				"#DDD",							// background color of switched/selected item
				"#777",							// border color
				"#CCC",							// border/font color of "inactive" key (key with no value/disabled)
				"#FFF",							// background color of "inactive" key (key with no value/disabled)
				"#F77",							// border color of language selector's cell
				wpvkb_key_flash,					// show key flash on click? (false by default)
				"#CC3300",						// font color during flash
				"#FF9966",						// key background color during flash
				"#CC3300",						// key border color during flash
				false,							// embed VKeyboard into the page?
				wpvkb_1pixel_gap,				// use 1-pixel gap between the keys?
				0);								// index (0-based) of the initial layout
			wpvkb.Show(wpvkb_visible);

			/* Make virtual keyboard mandatory */
			if (wpvkb_mandatory) {
				$('#comment').attr('readonly', true);
				$('#comment').focus(function() {
					wpvkb.Show(true);
				});
				$('#comment').blur(function() {
					wpvkb.Show(false);
				});
			}
		});
	/* ]]> */
	</script>
<?php
}
// Register the defined actions
if (function_exists('add_action')) {
	add_action('init', 'wpvkb_init');
	#Save Default Settings
	add_action( 'init','DefaultSettings');
	add_action('login_head', 'wpvkb_login_head');
	add_action('login_form', 'wpvkb_login_form');
	add_action('admin_menu', 'wpvkb_admin_menu');
	add_action('wp_head', 'wpvkb_comment_head');
	add_action('comment_form', 'wpvkb_comment_form');
}

?>

=== WP-Virtual-Keyboard ===
Contributors: Sithu Thwin
Tags: login, password, security, admin, keyboard, ayar, unicode, burmese, myanmar
Author URL: http://www.ayarunicodegroup.org 
URL:  http://www.ayarunicodegroup.org 
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 1.0

Displays a virtual, on-screen keyboard to enter the wordpress password in a safer way, for example in internet cafés. Display virtual keyboard on comment form. Support Ayar Myanmar Unicode Font for Burmese language.

== Description ==

Display virtual keyboard on comment form. Support Ayar Unicode Font for Burmese language. Optionally displays a virtual, on-screen keyboard to enter the password in more safe way, for example in internet cafés. Entering the password using an on-screen keyboard reduces the risk keyloggers can steal the password. The on-screen keyboard will be shown after clicking on the keyboard icon next to the password input box. Some options can be set, for example if a numeric keypad should be shown or not.

See my [other plugins](http://wordpress.org/extend/plugins/profile/ayar-unicode"Sithu Thwin").

== Installation ==

*Using the WordPress dashboard*

1. Login to your weblog
1. Go to Plugins
1. Select Add New
1. Search for WP-Virtual-Keyboard
1. Select Install
1. Select Install Now
1. Select Activate Plugin

--(or)--

1.Download Wp-virtual-keyboard.zip and unzip to your plugin directory.
2. Upload the entire wp-virtual-keyboard/ directory to the /wp-content/plugins/ directory
4.Activate it from your wordpress admin dashboard plugins menu.


== Screenshots ==

1. The virtual keyboard in action on login page
2.  The virtual keyboard in action on comment form


== Acknowledgments ==

This plugin uses:
*[Original Source Codes]Contributors: Marcel Bokhorst

* [jQuery JavaScript Library](http://jquery.com/ "jQuery") published under both the GNU General Public License and MIT License

* [JavaScript Virtual Keyboard](http://www.codeproject.com/KB/scripting/jvk.aspx "JavaScript Virtual Keyboard")
by *Dmitry Khudorozhkov* licensed under [CPOL](http://www.codeproject.com/info/cpol10.aspx "CPOL")

* [Keyboard icon](http://commons.wikimedia.org/wiki/File:Gnome-input-keyboard.svg "Keyboard icon")
licensed under [GPLv3](http://www.gnu.org/copyleft/gpl-3.0.html "GPLv3")
